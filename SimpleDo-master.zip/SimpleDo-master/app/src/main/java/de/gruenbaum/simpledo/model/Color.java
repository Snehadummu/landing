package de.gruenbaum.simpledo.model;

public enum Color
{
    DEFAULT,
    YELLOW,
    ORANGE,
    RED,
    GREEN,
    BLUE,
    PURPLE
}
