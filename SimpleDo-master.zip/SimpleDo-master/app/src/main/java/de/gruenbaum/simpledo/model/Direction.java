package de.gruenbaum.simpledo.model;

public enum Direction
{
    UP, DOWN, NONE;
}
