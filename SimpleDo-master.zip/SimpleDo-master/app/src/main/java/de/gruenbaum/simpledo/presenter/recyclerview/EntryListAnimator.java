package de.gruenbaum.simpledo.presenter.recyclerview;

import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.RecyclerView;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;


public class EntryListAnimator extends DefaultItemAnimator
{
}