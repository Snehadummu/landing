package de.gruenbaum.simpledo.model;

public enum Criterion
{
    TEXT, DEADLINE, COLOR, NONE;
}
