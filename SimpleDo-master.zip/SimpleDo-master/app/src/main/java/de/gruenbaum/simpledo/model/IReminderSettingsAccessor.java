package de.gruenbaum.simpledo.model;

public interface IReminderSettingsAccessor
{
    Time getAlldayTime();
    void setAlldayTime(Time newValue);
}
